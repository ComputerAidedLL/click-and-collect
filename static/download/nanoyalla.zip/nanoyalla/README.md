**This is NanoYalla version 1.0.1**

*tested with Coq >= 8.8*

Compile and install using:

    $ ./configure
    $ make
    $ make install
