**This is NanoYalla version 1.0.0**

Compile and install using:

    $ ./configure
    $ make
    $ make install
